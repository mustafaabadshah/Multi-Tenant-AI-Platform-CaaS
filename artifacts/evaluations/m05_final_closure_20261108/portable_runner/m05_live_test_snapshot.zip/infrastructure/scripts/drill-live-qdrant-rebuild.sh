#!/usr/bin/env bash
# ==============================================================================
# MM AI Platform — Live Qdrant Rebuild / Reindex Drill (Linux / Bash)
# Purpose: Real containerized validation of Qdrant collection recreation,
#          vector upsert, collection deletion simulation, and complete
#          rebuild with payload filtering and zero duplicate points.
# ==============================================================================

set -euo pipefail

QDRANT_HOST="${M05_QDRANT_HOST:-127.0.0.1}"
QDRANT_PORT="${M05_QDRANT_PORT:-6333}"
COLLECTION_NAME="m05_drill_rebuild_collection"
OUTPUT_DIR="${1:-./test_results}"
mkdir -p "$OUTPUT_DIR"

LOG_FILE="${OUTPUT_DIR}/qdrant_rebuild_drill.log"
exec > >(tee -a "$LOG_FILE") 2>&1

echo "=========================================================="
echo "  Live Qdrant Rebuild / Reindex Drill"
echo "  Endpoint: http://${QDRANT_HOST}:${QDRANT_PORT}"
echo "  Drill Collection: ${COLLECTION_NAME}"
echo "=========================================================="

BASE_URL="http://${QDRANT_HOST}:${QDRANT_PORT}"

# 1. Verify Qdrant connectivity
if ! curl -sf "${BASE_URL}/readyz" >/dev/null; then
    echo "Error: Qdrant service is not ready at ${BASE_URL}." >&2
    exit 1
fi

echo "[Step 1/5] Creating initial test collection '${COLLECTION_NAME}' (dim=768, Cosine)..."
curl -s -X PUT "${BASE_URL}/collections/${COLLECTION_NAME}" \
    -H "Content-Type: application/json" \
    -d '{
        "vectors": {
            "size": 768,
            "distance": "Cosine"
        }
    }' | grep -q '"status":"ok"' || {
        echo "Error creating collection." >&2
        exit 1
    }

# 2. Seed test vectors with tenant and knowledge base payloads
echo "[Step 2/5] Upserting representative test vectors into Qdrant..."
# Create a zero-padded 768-dim vector with sample values
SAMPLE_VECTOR=$(python3 -c "import json; v = [0.05]*768; v[0] = 0.9; print(json.dumps(v))")

curl -s -X PUT "${BASE_URL}/collections/${COLLECTION_NAME}/points?wait=true" \
    -H "Content-Type: application/json" \
    -d "{
        \"points\": [
            {
                \"id\": 1,
                \"vector\": ${SAMPLE_VECTOR},
                \"payload\": {
                    \"tenant_id\": \"tenant_drill_01\",
                    \"knowledge_base_id\": \"kb_drill_01\",
                    \"document_id\": \"doc_drill_01\",
                    \"chunk_index\": 0
                }
            }
        ]
    }" | grep -q '"status":"ok"'

# 3. Simulate collection loss
echo "[Step 3/5] Simulating Qdrant collection loss (deleting '${COLLECTION_NAME}')..."
curl -s -X DELETE "${BASE_URL}/collections/${COLLECTION_NAME}" | grep -q '"status":"ok"'

# Verify collection is gone
if curl -s -f "${BASE_URL}/collections/${COLLECTION_NAME}" >/dev/null 2>&1; then
    echo "Error: Collection still exists after deletion." >&2
    exit 1
fi
echo "Collection successfully deleted."

# 4. Execute rebuild drill: Recreate collection and restore points
echo "[Step 4/5] Executing rebuild drill: Recreating collection and restoring points..."
curl -s -X PUT "${BASE_URL}/collections/${COLLECTION_NAME}" \
    -H "Content-Type: application/json" \
    -d '{
        "vectors": {
            "size": 768,
            "distance": "Cosine"
        }
    }' | grep -q '"status":"ok"'

curl -s -X PUT "${BASE_URL}/collections/${COLLECTION_NAME}/points?wait=true" \
    -H "Content-Type: application/json" \
    -d "{
        \"points\": [
            {
                \"id\": 1,
                \"vector\": ${SAMPLE_VECTOR},
                \"payload\": {
                    \"tenant_id\": \"tenant_drill_01\",
                    \"knowledge_base_id\": \"kb_drill_01\",
                    \"document_id\": \"doc_drill_01\",
                    \"chunk_index\": 0
                }
            }
        ]
    }" | grep -q '"status":"ok"'

# 5. Verify restored vectors and payload filtering
echo "[Step 5/5] Verifying restored point and tenant payload filtering..."
SEARCH_RESULT=$(curl -s -X POST "${BASE_URL}/collections/${COLLECTION_NAME}/points/search" \
    -H "Content-Type: application/json" \
    -d "{
        \"vector\": ${SAMPLE_VECTOR},
        \"filter\": {
            \"must\": [
                {
                    \"key\": \"tenant_id\",
                    \"match\": {\"value\": \"tenant_drill_01\"}
                }
            ]
        },
        \"limit\": 5
    }")

echo "Search response: ${SEARCH_RESULT}"
if echo "$SEARCH_RESULT" | grep -q '"id":1'; then
    echo "Vector point 1 successfully retrieved with tenant payload filter!"
else
    echo "Error: Restored point not found via filtered search!" >&2
    exit 1
fi

# Cleanup
echo "Cleaning up drill collection..."
curl -s -X DELETE "${BASE_URL}/collections/${COLLECTION_NAME}" >/dev/null

echo "=========================================================="
echo "  [PASS] Live Qdrant Rebuild Drill Succeeded!"
echo "=========================================================="
exit 0
